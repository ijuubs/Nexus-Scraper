
import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import { performScrape } from './scraper';

const app = express();
const PORT = 3001;

app.use(cors());
app.use(bodyParser.json());

app.get('/api/health', (req, res) => {
    res.json({ status: 'healthy', timestamp: new Date() });
});

app.post('/api/scrape', async (req, res) => {
    const { url, strategy, selectors, id } = req.body;
    
    if (!url || !selectors) {
         res.status(400).json({ error: 'Missing configuration' });
         return;
    }

    console.log(`[Job ${id}] Received scrape request for ${url}`);
    
    // In a real production app, this would be offloaded to a queue (BullMQ/Redis)
    // For this dashboard, we await it to return the result directly
    try {
        const result = await performScrape({
            url,
            strategy,
            selectors
        });
        
        res.json(result);
    } catch (e: any) {
        console.error(e);
        res.status(500).json({ success: false, error: e.message });
    }
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log(`Scraper ready for commands.`);
});
