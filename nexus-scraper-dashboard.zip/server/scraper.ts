
import * as cheerio from 'cheerio';
import puppeteer from 'puppeteer';
import axios from 'axios';

interface ScrapeConfig {
    url: string;
    strategy: 'STATIC' | 'DYNAMIC' | 'API';
    selectors: {
        container: string;
        name: string;
        price: string;
        image: string;
    };
}

export interface ScrapeResult {
    success: boolean;
    data: any[];
    log: string[];
    count: number;
}

const USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36',
];

export const performScrape = async (config: ScrapeConfig): Promise<ScrapeResult> => {
    const logs: string[] = [];
    const addLog = (msg: string) => logs.push(`[${new Date().toISOString()}] ${msg}`);
    
    addLog(`Starting scrape for ${config.url} using ${config.strategy}`);

    try {
        if (config.strategy === 'STATIC') {
            return await scrapeStatic(config, addLog, logs);
        } else if (config.strategy === 'DYNAMIC') {
            return await scrapeDynamic(config, addLog, logs);
        } else {
            throw new Error('API Strategy not yet implemented in backend');
        }
    } catch (error: any) {
        addLog(`ERROR: ${error.message}`);
        return { success: false, data: [], log: logs, count: 0 };
    }
};

async function scrapeStatic(config: ScrapeConfig, addLog: (m: string) => void, logs: string[]) {
    addLog('Fetching HTML content via Axios...');
    const { data } = await axios.get(config.url, {
        headers: { 'User-Agent': USER_AGENTS[0] }
    });
    
    addLog(`Content received (${data.length} bytes). Parsing with Cheerio...`);
    const $ = cheerio.load(data);
    
    const products: any[] = [];
    $(config.selectors.container).each((_, el) => {
        const name = $(el).find(config.selectors.name).text().trim();
        const price = $(el).find(config.selectors.price).text().trim();
        const image = $(el).find(config.selectors.image).attr('src');
        
        if (name) {
            products.push({ name, price, image, source: config.url });
        }
    });

    addLog(`Extraction complete. Found ${products.length} items.`);
    return { success: true, data: products, log: logs, count: products.length };
}

async function scrapeDynamic(config: ScrapeConfig, addLog: (m: string) => void, logs: string[]) {
    addLog('Launching Headless Browser (Puppeteer)...');
    
    // 'new' headless mode is the modern standard. 
    // --no-sandbox is required for many CI/Server environments (though less secure for untrusted content).
    const browser = await puppeteer.launch({ 
        headless: 'new',
        args: ['--no-sandbox', '--disable-setuid-sandbox'] 
    });
    
    const page = await browser.newPage();
    
    try {
        await page.setUserAgent(USER_AGENTS[0]);
        await page.setViewport({ width: 1280, height: 800 });

        addLog('Navigating to page...');
        await page.goto(config.url, { waitUntil: 'networkidle2', timeout: 60000 });
        
        addLog('Waiting for selectors to appear...');
        // Wait for at least one item to appear
        await page.waitForSelector(config.selectors.container, { timeout: 15000 }).catch(() => {
            addLog('Warning: Container selector not found within timeout.');
        });
        
        addLog('Evaluating DOM content...');
        const products = await page.evaluate((sels) => {
            const items: any[] = [];
            document.querySelectorAll(sels.container).forEach((el) => {
                const nameEl = el.querySelector(sels.name);
                const priceEl = el.querySelector(sels.price);
                const imgEl = el.querySelector(sels.image);
                
                if (nameEl) {
                    items.push({
                        name: nameEl.textContent?.trim(),
                        price: priceEl?.textContent?.trim(),
                        image: imgEl?.getAttribute('src'),
                    });
                }
            });
            return items;
        }, config.selectors);

        addLog(`Extraction complete. Found ${products.length} items.`);
        return { success: true, data: products, log: logs, count: products.length };
        
    } finally {
        await browser.close();
        addLog('Browser closed.');
    }
}
