import React, { useState, useEffect } from 'react';
import { Bot, Save, Play, Code, AlertCircle, Wand2, Loader } from 'lucide-react';
import { ScraperConfig, SiteStrategy } from '../types';
import { analyzeHtmlForSelectors, SelectorPrediction } from '../services/geminiService';

interface ScraperBuilderProps {
  onSave: (config: Omit<ScraperConfig, 'id' | 'status' | 'lastRun' | 'productsCount'>) => void;
  initialData?: ScraperConfig;
  onCancel: () => void;
}

export const ScraperBuilder: React.FC<ScraperBuilderProps> = ({ onSave, initialData, onCancel }) => {
  const [name, setName] = useState(initialData?.name || '');
  const [baseUrl, setBaseUrl] = useState(initialData?.baseUrl || '');
  const [strategy, setStrategy] = useState<SiteStrategy>(initialData?.strategy || SiteStrategy.STATIC);
  const [schedule, setSchedule] = useState(initialData?.schedule || 'Daily @ 00:00');
  
  // Selectors
  const [container, setContainer] = useState(initialData?.selectors.productContainer || '');
  const [nameSel, setNameSel] = useState(initialData?.selectors.name || '');
  const [priceSel, setPriceSel] = useState(initialData?.selectors.price || '');
  const [imageSel, setImageSel] = useState(initialData?.selectors.image || '');

  // UI State
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [htmlSnippet, setHtmlSnippet] = useState('');
  const [aiConfidence, setAiConfidence] = useState<number | null>(null);

  const handleAnalyze = async () => {
    if (!htmlSnippet) return;
    setIsAnalyzing(true);
    try {
      const result: SelectorPrediction = await analyzeHtmlForSelectors(htmlSnippet, baseUrl);
      setContainer(result.container);
      setNameSel(result.name);
      setPriceSel(result.price);
      setImageSel(result.image);
      setStrategy(result.strategyRecommendation === 'DYNAMIC' ? SiteStrategy.DYNAMIC : 
                  result.strategyRecommendation === 'API' ? SiteStrategy.API : SiteStrategy.STATIC);
      setAiConfidence(result.confidence);
    } catch (e) {
      console.error(e);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    
    // Simulate API delay for better UX
    await new Promise(resolve => setTimeout(resolve, 1200));

    onSave({
      name,
      baseUrl,
      strategy,
      schedule,
      selectors: {
        productContainer: container,
        name: nameSel,
        price: priceSel,
        image: imageSel,
      }
    });
    setIsSaving(false);
  };

  return (
    <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
      <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
        <div>
          <h2 className="text-xl font-bold text-slate-800">
            {initialData ? 'Edit Scraper Agent' : 'Build New Scraper Agent'}
          </h2>
          <p className="text-sm text-slate-500">Configure target site and extraction rules</p>
        </div>
        <div className="flex space-x-2">
           <button 
            type="button" 
            onClick={onCancel}
            disabled={isSaving}
            className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 disabled:opacity-50"
          >
            Cancel
          </button>
          <button 
            onClick={handleSubmit}
            disabled={isSaving}
            className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 flex items-center disabled:bg-blue-400 min-w-[180px] justify-center"
          >
            {isSaving ? (
              <>
                <Loader size={16} className="animate-spin mr-2" />
                Saving Config...
              </>
            ) : (
              <>
                <Save size={16} className="mr-2" />
                Save Configuration
              </>
            )}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2">
        {/* Left Column: Configuration Form */}
        <div className="p-6 border-r border-slate-100 space-y-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Agent Name</label>
              <input 
                type="text" 
                value={name} 
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                placeholder="e.g., RB Patel Scraper" 
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Target Base URL</label>
              <input 
                type="url" 
                value={baseUrl} 
                onChange={(e) => setBaseUrl(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                placeholder="https://..." 
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Strategy</label>
                <select 
                  value={strategy}
                  onChange={(e) => setStrategy(e.target.value as SiteStrategy)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white"
                >
                  <option value={SiteStrategy.STATIC}>Static (Cheerio)</option>
                  <option value={SiteStrategy.DYNAMIC}>Dynamic (Playwright)</option>
                  <option value={SiteStrategy.API}>Direct API</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Schedule</label>
                <input 
                  type="text" 
                  value={schedule} 
                  onChange={(e) => setSchedule(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  placeholder="e.g., Daily @ 02:00" 
                />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100">
            <h3 className="text-sm font-bold text-slate-900 mb-4 flex items-center">
              <Code size={16} className="mr-2 text-blue-500" />
              CSS Selectors
            </h3>
            
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Product Container</label>
                <input 
                  type="text" 
                  value={container}
                  onChange={(e) => setContainer(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-mono text-sm text-slate-700 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none"
                  placeholder=".product-item"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Name Selector</label>
                <input 
                  type="text" 
                  value={nameSel}
                  onChange={(e) => setNameSel(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-mono text-sm text-slate-700 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none"
                  placeholder=".product-title"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Price Selector</label>
                <input 
                  type="text" 
                  value={priceSel}
                  onChange={(e) => setPriceSel(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-mono text-sm text-slate-700 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none"
                  placeholder=".price-value"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Image Selector</label>
                <input 
                  type="text" 
                  value={imageSel}
                  onChange={(e) => setImageSel(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-mono text-sm text-slate-700 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none"
                  placeholder=".product-img img"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: AI Helper */}
        <div className="p-6 bg-slate-50 h-full flex flex-col">
          <div className="mb-4">
            <h3 className="text-lg font-semibold text-slate-800 flex items-center">
              <Wand2 size={20} className="mr-2 text-purple-600" />
              Gemini Selector Assistant
            </h3>
            <p className="text-sm text-slate-600 mt-1">
              Paste the <strong>Product List</strong> HTML section from your target site (Inspect Element -> Copy Outer HTML). Gemini will detect the repeating pattern.
            </p>
          </div>

          <div className="flex-1 mb-4">
            <textarea
              value={htmlSnippet}
              onChange={(e) => setHtmlSnippet(e.target.value)}
              placeholder="<div class='product-list'>...</div>"
              className="w-full h-full min-h-[300px] p-4 border border-slate-300 rounded-lg font-mono text-xs focus:ring-2 focus:ring-purple-500 outline-none resize-none"
            ></textarea>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              {aiConfidence && (
                <span className="text-xs font-medium px-2 py-1 bg-green-100 text-green-700 rounded-full flex items-center">
                  <Bot size={12} className="mr-1"/>
                  Confidence: {Math.round(aiConfidence * 100)}%
                </span>
              )}
            </div>
            <button
              type="button"
              onClick={handleAnalyze}
              disabled={!htmlSnippet || isAnalyzing}
              className={`px-4 py-2 rounded-lg text-sm font-medium text-white flex items-center transition-all ${
                !htmlSnippet || isAnalyzing ? 'bg-slate-400 cursor-not-allowed' : 'bg-purple-600 hover:bg-purple-700 shadow-md hover:shadow-lg'
              }`}
            >
              {isAnalyzing ? (
                <>Analyzing...</>
              ) : (
                <>
                  <Bot size={16} className="mr-2" />
                  Auto-Detect Selectors
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};