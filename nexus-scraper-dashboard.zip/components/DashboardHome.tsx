import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Activity, Database, Server, CheckCircle, AlertTriangle } from 'lucide-react';
import { DashboardStats, JobLog } from '../types';

interface DashboardHomeProps {
  stats: DashboardStats;
  recentLogs: JobLog[];
}

const data = [
  { name: 'Mon', products: 12400 },
  { name: 'Tue', products: 12800 },
  { name: 'Wed', products: 13100 },
  { name: 'Thu', products: 12900 },
  { name: 'Fri', products: 13515 },
  { name: 'Sat', products: 13515 },
  { name: 'Sun', products: 13515 },
];

export const DashboardHome: React.FC<DashboardHomeProps> = ({ stats, recentLogs }) => {
  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-100 flex items-center space-x-4">
          <div className="p-3 bg-blue-100 text-blue-600 rounded-lg">
            <Database size={24} />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-500">Total Products</p>
            <h3 className="text-2xl font-bold text-slate-800">{stats.totalProducts.toLocaleString()}</h3>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-100 flex items-center space-x-4">
          <div className="p-3 bg-indigo-100 text-indigo-600 rounded-lg">
            <Activity size={24} />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-500">Active Scrapers</p>
            <h3 className="text-2xl font-bold text-slate-800">{stats.activeScrapers}</h3>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-100 flex items-center space-x-4">
          <div className="p-3 bg-green-100 text-green-600 rounded-lg">
            <CheckCircle size={24} />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-500">Success Rate</p>
            <h3 className="text-2xl font-bold text-slate-800">{stats.successRate}%</h3>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-100 flex items-center space-x-4">
          <div className="p-3 bg-purple-100 text-purple-600 rounded-lg">
            <Server size={24} />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-500">Data Volume</p>
            <h3 className="text-2xl font-bold text-slate-800">{stats.totalDataVolume}</h3>
          </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Chart Area */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-slate-100 p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Total Products Indexed</h3>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorProducts" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Area type="monotone" dataKey="products" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#colorProducts)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Recent Activity Feed */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Recent Jobs</h3>
          <div className="space-y-4">
            {recentLogs.map((log) => (
              <div key={log.id} className="flex items-start justify-between p-3 rounded-lg hover:bg-slate-50 transition-colors">
                <div className="flex items-center space-x-3">
                  <div className={`w-2 h-2 rounded-full ${
                    log.status === 'SUCCESS' ? 'bg-green-500' :
                    log.status === 'FAILED' ? 'bg-red-500' : 'bg-yellow-500'
                  }`} />
                  <div>
                    <p className="text-sm font-medium text-slate-900">{log.scraperName}</p>
                    <p className="text-xs text-slate-500">
                      {new Date(log.startTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})} • {log.duration}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <span className={`text-xs font-semibold px-2 py-1 rounded-full ${
                    log.status === 'SUCCESS' ? 'bg-green-100 text-green-700' :
                    log.status === 'FAILED' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'
                  }`}>
                    {log.status}
                  </span>
                  <p className="text-xs text-slate-500 mt-1">{log.itemsScraped} items</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
